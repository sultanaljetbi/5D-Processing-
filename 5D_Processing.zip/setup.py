
from setuptools import setup, find_packages

setup(
    name="five_d_processing",
    version="1.0.0",
    author="Sultan",
    description="A versatile library for 5D data processing and optimization.",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "scipy"
    ],
    classifiers=[
        "Programming Language :: Python :: 3.9",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
